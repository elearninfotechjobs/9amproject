a=[1,2,3,4,5]
b=iter(reversed(a))

print(next(b))
print(next(b))
